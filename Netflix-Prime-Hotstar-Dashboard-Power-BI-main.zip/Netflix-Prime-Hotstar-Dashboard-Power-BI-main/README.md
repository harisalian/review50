# Netflix-Prime-Hotstar-Dashboard-Power-BI

[![Views](https://visitor-badge.glitch.me/badge?page_id=undiscovered-genius.undiscovered-genius/Netflix-Prime-Hotstar-Dashboard-Power-BI)](https://github.com/undiscovered-genius/Netflix-Prime-Hotstar-Dashboard-Power-BI)

## Dataset (Kaggle)
### Netflix Dataset - https://www.kaggle.com/datasets/shivamb/netflix-shows
### Amazon Prime Dataset - https://www.kaggle.com/datasets/shivamb/amazon-prime-movies-and-tv-shows
### Hotstar Dataset - https://www.kaggle.com/datasets/shivamb/disney-movies-and-tv-shows

<img src='Pics\1.jpg' class="center">
<img src='Pics\2.jpg' class="center">
<img src='Pics\3.jpg' class="center">

